package com.example.david.connectgame;

import android.graphics.Color;

public class C {
    public static int FREE = Color.WHITE;
    public static int FIRST = 0xFF0000FF;
    public static int SECOND =  0xFFFF0000;
    public static int NULL = Color.rgb(0xd0, 0xd0,0xd0);
    public static int FOCUSED = 0x8000FFFF;
}
