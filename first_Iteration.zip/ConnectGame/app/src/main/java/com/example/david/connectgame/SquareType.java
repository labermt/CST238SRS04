package com.example.david.connectgame;

public enum SquareType {
    FREE,
    FIRST_PLAYER,
    SECOND_PLAYER,
    NULL
}
